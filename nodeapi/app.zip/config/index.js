module.exports = {

    wpapi: {
        'prod': 'https://www.dreamteamfc.com/c/wp-json/wp/v2/',
        'local': 'http://dtfc/c/wp-json/wp/v2/',
    }

};