var React = require('react');
 
var output = React.createClass({
  render: function() {
    return (
        <header>
         

        </header>
    );
  }
});
 
module.exports = output;