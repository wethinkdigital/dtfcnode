var React = require('react');
 
var output = React.createClass({
  render: function() {
    return (
        <footer>
          <h3>This my footer</h3>
        </footer>
    );
  }
});
 
module.exports = output;